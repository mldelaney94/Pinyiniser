Creates pinyin from lists of chinese strings
