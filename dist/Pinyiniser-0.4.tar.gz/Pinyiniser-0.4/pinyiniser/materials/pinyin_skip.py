"""For all those words that have multiple pronunciations, we remove the rarer
one"""

skip = {'要 要 [yao1] ', '與 与 [yu2] ', '舍 舍 [she3] '}
